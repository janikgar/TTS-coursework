print "First Name: "
first = gets.chomp
print "Last Name: "
last = gets.chomp

puts "Your full name is #{first} #{last}."
puts "That name has #{first.length + last.length} letters in it."