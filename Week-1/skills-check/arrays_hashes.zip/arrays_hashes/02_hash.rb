hash = {"x" => 3, "y" => 2, "z" => 1}

puts hash["y"]