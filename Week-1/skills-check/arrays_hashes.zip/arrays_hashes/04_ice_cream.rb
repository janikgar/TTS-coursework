ice_cream = ["vanilla", "chocolate", "rocky road"]
ice_cream.push("strawberry")
puts ice_cream.join(", ")