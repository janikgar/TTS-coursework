array = ["x", "y", "z"]
puts array[1]