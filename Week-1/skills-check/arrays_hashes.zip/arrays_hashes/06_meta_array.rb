num_array = [4,6,[2,7,3]]

puts num_array[2][1]