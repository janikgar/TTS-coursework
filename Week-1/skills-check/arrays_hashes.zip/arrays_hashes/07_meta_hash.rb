atlanta_teams = {baseball: "braves", football: "falcons", hawks_players: {pointguard: "Jeff Teague", power_forward: "Paul Millsap", forward_center: "Al Horford"}}

puts atlanta_teams[:hawks_players][:power_forward]