nola_teams = {"baseball" => "Zephyrs", "football" => "Saints"}
nola_teams["basketball"] = "Pelicans"

puts nola_teams