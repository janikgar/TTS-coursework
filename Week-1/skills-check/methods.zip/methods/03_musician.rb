def my_favorite_musician(first_name, last_name)
	puts "My favorite musician is #{first_name} #{last_name}."
end

my_favorite_musician("Robert", "Plant")