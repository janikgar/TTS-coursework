def rock
	puts "I wanna rock!"
end

4.times do
	rock
end