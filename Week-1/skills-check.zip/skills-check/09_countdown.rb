countdown = [1,2,3,4,5]
countdown.reverse.each do |x|
	puts x
end
puts "Blastoff!"