10.times do 
	puts "What's Up?"
end