fish = 1
while fish < 4 do
	puts "#{fish} fish"
	fish += 1
end
puts "blue fish"