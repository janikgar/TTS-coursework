atl_neighborhoods = ["Viriginia Highlands", "Grant Park", "Buckhead"]

atl_neighborhoods.each_with_index do |neighborhood, index|
	puts "#{index}: #{neighborhood}"
end