6.times do |count|
	puts count
end