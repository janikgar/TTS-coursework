array = [2,3,4,5]

array.each do |x|
	puts x
end

6.times do |count|
	if count > 1
		puts count
	end
end