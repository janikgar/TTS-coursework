puts "What's your mood today?"

mood = gets.chomp

puts "meow #{mood}"