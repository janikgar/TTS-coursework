puts "Give me a number"
num1 = gets.chomp.to_f
puts "OK, give me another number"
num2 = gets.chomp.to_f

puts "The sum is #{(num1 + num2)}"
puts "The difference is #{(num1-num2)}"
puts "The product is #{(num1*num2)}"
puts "The quotient is #{num1/num2}"