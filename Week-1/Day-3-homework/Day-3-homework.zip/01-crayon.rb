puts "What is your favorite Crayola crayon?"

crayon = gets.chomp

puts crayon.reverse.upcase