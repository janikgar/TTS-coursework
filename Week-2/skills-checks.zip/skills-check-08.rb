user1 = {firstname: "Johnny", lastname: "Begood", gender: "male", dob: "08/21/1981", birthplace: "Seattle, WA"}
user1[:current_city] = "Atlanta, GA"
puts user1