alphabits = {"d"=>4, "k"=>14, "u"=>52}
puts alphabits["k"]