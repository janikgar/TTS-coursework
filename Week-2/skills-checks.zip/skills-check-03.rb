to_do = ["wash the car", "buy groceries", "finish homework", "pay the bills"]

to_do.each do |item|
	puts "Don't forgot to #{item}."
end