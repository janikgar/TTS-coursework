wild_cats = ['cheetah', 'lion', 'leopard', 'tiger']
wild_cats.push('bobcat')

puts wild_cats