alpha_soup=["c", "k", "y", "u"]
puts alpha_soup[2]