num = nil
until num == 3 do
	num = rand(1..10)
	puts num
end