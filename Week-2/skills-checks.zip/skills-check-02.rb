def sum_numbers(x,y,z)
	x+y+z
end

puts sum_numbers(3,4,5)