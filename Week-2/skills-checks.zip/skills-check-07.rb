user1 = {firstname: "Johnny", lastname: "Begood", gender: "male", dob: "08/21/1981", birthplace: "Seattle, WA"}
puts user1[:birthplace]